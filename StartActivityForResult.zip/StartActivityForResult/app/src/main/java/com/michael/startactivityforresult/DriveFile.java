package com.michael.startactivityforresult;

import java.io.Serializable;

class DriveFile implements Serializable {
    static final long serialVersionUID = 42L;


}
