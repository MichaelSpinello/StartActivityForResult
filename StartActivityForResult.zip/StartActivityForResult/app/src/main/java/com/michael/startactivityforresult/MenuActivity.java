package com.michael.startactivityforresult;

import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {
}
